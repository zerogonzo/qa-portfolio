# Playwright Framework

Example structure for a maintainable Playwright automation framework.

## Concepts Demonstrated

- Page Object Model
- Reusable fixtures
- API-assisted setup
- Smoke and regression test organization
- CI/CD readiness
