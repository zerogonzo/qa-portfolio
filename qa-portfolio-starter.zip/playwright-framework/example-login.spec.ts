// Example Playwright-style test structure
// This is a portfolio sample, not tied to a real application.

import { test, expect } from '@playwright/test';

test('user can access dashboard after login', async ({ page }) => {
  await page.goto('https://example.com/login');
  await page.fill('[data-testid="email"]', 'test@example.com');
  await page.fill('[data-testid="password"]', 'Password123!');
  await page.click('[data-testid="login-button"]');

  await expect(page.locator('[data-testid="dashboard"]')).toBeVisible();
});
