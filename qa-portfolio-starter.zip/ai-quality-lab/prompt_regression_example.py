# Example only. This file demonstrates the evaluation logic concept
# without calling a live AI provider.

expected_keywords = ["refund", "policy", "customer"]

sample_response = '''
The customer should be directed to the refund policy and provided clear next steps.
'''

def test_response_contains_expected_concepts():
    response_lower = sample_response.lower()
    for keyword in expected_keywords:
        assert keyword in response_lower

def test_response_is_not_empty():
    assert len(sample_response.strip()) > 0
