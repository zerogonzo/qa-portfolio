# AI Quality Lab

Examples for thinking about quality in AI-assisted and LLM-powered applications.

## Concepts Demonstrated

- Prompt regression testing
- Structured output validation
- Hallucination risk checks
- Consistency and relevance evaluation
- Human oversight in AI quality workflows
