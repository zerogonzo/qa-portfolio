# API Automation with PyTest

Example API automation structure focused on maintainable backend validation.

## Concepts Demonstrated

- REST API validation
- Status code and response schema checks
- Negative testing
- Data-driven test structure
