-- Find duplicate customer emails
SELECT email, COUNT(*) AS total
FROM customers
GROUP BY email
HAVING COUNT(*) > 1;

-- Identify orders missing customer references
SELECT o.order_id
FROM orders o
LEFT JOIN customers c ON o.customer_id = c.customer_id
WHERE c.customer_id IS NULL;

-- Validate paid orders have payment dates
SELECT order_id
FROM orders
WHERE status = 'PAID'
AND payment_date IS NULL;
