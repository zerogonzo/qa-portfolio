# SQL Validation Examples

Examples of SQL checks used in QA to validate data integrity.

## Concepts Demonstrated

- Record reconciliation
- Duplicate detection
- Null checks
- Referential integrity checks
